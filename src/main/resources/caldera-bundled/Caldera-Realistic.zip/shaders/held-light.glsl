#if _CALDERA_ENABLED_HELD_LIGHTING
uniform sampler2D CalderaHeldShadow0;
uniform sampler2D CalderaHeldShadow1;
uniform sampler2D CalderaHeldShadow2;
uniform sampler2D CalderaHeldShadow3;
uniform sampler2D CalderaHeldShadow4;
uniform sampler2D CalderaHeldShadow5;
vec4 heldGather(int face,vec2 uv) {
    if(face==0) return textureGather(CalderaHeldShadow0,uv);
    if(face==1) return textureGather(CalderaHeldShadow1,uv);
    if(face==2) return textureGather(CalderaHeldShadow2,uv);
    if(face==3) return textureGather(CalderaHeldShadow3,uv);
    if(face==4) return textureGather(CalderaHeldShadow4,uv);
    return textureGather(CalderaHeldShadow5,uv);
}
float heldLightVisibility(vec3 receiver,vec3 normal) {
    vec3 ray=receiver-HeldLightPositionRadius.xyz, a=abs(ray);
    int face=a.x>=a.y && a.x>=a.z?(ray.x>=0.0?0:1):a.y>=a.z?(ray.y>=0.0?2:3):(ray.z>=0.0?4:5);
    // Small world-space receiver offset keeps animated cutouts attached to their shadows.
    vec3 biased=receiver+normal*0.012;
    vec4 clip=HeldLightViewProjection[face]*vec4(biased,1);
    if(clip.w<=0.05) return 1.0;
    vec3 coord=clip.xyz/clip.w; vec2 uv=coord.xy*0.5+0.5;
    vec2 size=vec2(textureSize(CalderaHeldShadow0,0));
    vec2 f=fract(uv*size-0.5);
    // Perspective receiver-plane correction prevents acne without a large depth bias.
    vec3 axis=abs(normal.y)<0.9?vec3(0,1,0):vec3(1,0,0);
    vec3 tangent=normalize(cross(normal,axis)), bitangent=cross(normal,tangent);
    vec4 tx=HeldLightViewProjection[face]*vec4(tangent,0);
    vec4 ty=HeldLightViewProjection[face]*vec4(bitangent,0);
    vec3 dx=(tx.xyz-coord*tx.w)/clip.w, dy=(ty.xyz-coord*ty.w)/clip.w;
    vec2 ux=dx.xy*0.5, uy=dy.xy*0.5;
    float determinant=ux.x*uy.y-ux.y*uy.x;
    vec2 gradient=abs(determinant)<1e-10?vec2(0):vec2(dx.z*uy.y-dy.z*ux.y,ux.x*dy.z-uy.x*dx.z)/determinant;
    gradient=clamp(gradient,vec2(-2),vec2(2));
    vec2 lower=(floor(uv*size-0.5)+0.5)/size-uv;
    float reference=coord.z-0.000002;
    vec4 comparison=reference+vec4(dot(gradient,lower+vec2(0,1)/size),
        dot(gradient,lower+1.0/size),dot(gradient,lower+vec2(1,0)/size),dot(gradient,lower));
    vec4 visible=step(comparison,heldGather(face,uv));
    return mix(mix(visible.w,visible.z,f.x),mix(visible.x,visible.y,f.x),f.y);
}
#endif
vec3 calderaHeldLight(vec3 position,vec3 normal) {
#if _CALDERA_ENABLED_HELD_LIGHTING
    float radius=HeldLightPositionRadius.w;
    vec3 delta=HeldLightPositionRadius.xyz-position;
    float distanceSquared=dot(delta,delta);
    if(radius<=0.0 || distanceSquared>=radius*radius) return vec3(0);
    float facing=max(dot(normal,delta*inversesqrt(max(distanceSquared,1e-6))),0.0);
    if(facing<=0.0) return vec3(0);
    float edge=1.0-distanceSquared/(radius*radius);
    float attenuation=edge*edge/(1.0+distanceSquared*0.055);
    return HeldLightColor.rgb*(HELD_LIGHTING*attenuation*facing*heldLightVisibility(position,normal));
#else
    return vec3(0);
#endif
}
