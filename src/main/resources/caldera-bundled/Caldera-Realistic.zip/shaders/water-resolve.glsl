uniform sampler2D WaterReflection;
vec3 resolveWaterReflection(vec2 uv,uvec2 data,vec3 position,vec3 local) {
    vec4 reflected=texelFetch(WaterReflection,ivec2(uv*ViewSizeAndInverse.xy),0);
    if(reflected.a<=0.0) return local;
    vec3 normal=surfaceNormal(data.x);
    vec3 toEye=normalize(calderaCameraOffset()-position);
    float f0=surfaceIce(data)?0.025:0.02;
    float fresnel=f0+(1.0-f0)*pow(1.0-abs(dot(normal,toEye)),5.0);
    return mix(local,reflected.rgb,fresnel*WATER_REFLECTION_STRENGTH*surfaceVisibility(data));
}
